/*
  Warnings:

  - A unique constraint covering the columns `[userId]` on the table `Admin` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[studentId,date]` on the table `StudentAttendence` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId,date]` on the table `TeacherAttendence` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX `StudentAttendence_date_key` ON `studentattendence`;

-- DropIndex
DROP INDEX `TeacherAttendence_date_key` ON `teacherattendence`;

-- AlterTable
ALTER TABLE `studentattendence` ALTER COLUMN `date` DROP DEFAULT;

-- AlterTable
ALTER TABLE `teacherattendence` ALTER COLUMN `date` DROP DEFAULT;

-- CreateIndex
CREATE UNIQUE INDEX `Admin_userId_key` ON `Admin`(`userId`);

-- CreateIndex
CREATE UNIQUE INDEX `StudentAttendence_studentId_date_key` ON `StudentAttendence`(`studentId`, `date`);

-- CreateIndex
CREATE UNIQUE INDEX `TeacherAttendence_teacherId_date_key` ON `TeacherAttendence`(`teacherId`, `date`);
