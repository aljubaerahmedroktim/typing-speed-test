/*
  Warnings:

  - A unique constraint covering the columns `[subject_name]` on the table `Lesson` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX `Lesson_subject_name_key` ON `Lesson`(`subject_name`);
