/*
  Warnings:

  - A unique constraint covering the columns `[userId]` on the table `Announcement` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId]` on the table `Class` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[classId]` on the table `Event` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[classId]` on the table `Exam` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[lessonId]` on the table `Exam` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId]` on the table `Lesson` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[classId]` on the table `Lesson` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[userId]` on the table `Parent` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[studentId]` on the table `ParentStudent` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[parentId]` on the table `ParentStudent` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[teacherId]` on the table `Result` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[classId]` on the table `Result` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[lessonId]` on the table `Result` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[examId]` on the table `Result` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[studentId]` on the table `Result` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[userId]` on the table `Student` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[userId]` on the table `Teacher` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `studentattendence` ALTER COLUMN `date` DROP DEFAULT;

-- AlterTable
ALTER TABLE `teacherattendence` ALTER COLUMN `date` DROP DEFAULT;

-- CreateIndex
CREATE UNIQUE INDEX `Announcement_userId_key` ON `Announcement`(`userId`);

-- CreateIndex
CREATE UNIQUE INDEX `Class_teacherId_key` ON `Class`(`teacherId`);

-- CreateIndex
CREATE UNIQUE INDEX `Event_classId_key` ON `Event`(`classId`);

-- CreateIndex
CREATE UNIQUE INDEX `Exam_classId_key` ON `Exam`(`classId`);

-- CreateIndex
CREATE UNIQUE INDEX `Exam_lessonId_key` ON `Exam`(`lessonId`);

-- CreateIndex
CREATE UNIQUE INDEX `Lesson_teacherId_key` ON `Lesson`(`teacherId`);

-- CreateIndex
CREATE UNIQUE INDEX `Lesson_classId_key` ON `Lesson`(`classId`);

-- CreateIndex
CREATE UNIQUE INDEX `Parent_userId_key` ON `Parent`(`userId`);

-- CreateIndex
CREATE UNIQUE INDEX `ParentStudent_studentId_key` ON `ParentStudent`(`studentId`);

-- CreateIndex
CREATE UNIQUE INDEX `ParentStudent_parentId_key` ON `ParentStudent`(`parentId`);

-- CreateIndex
CREATE UNIQUE INDEX `Result_teacherId_key` ON `Result`(`teacherId`);

-- CreateIndex
CREATE UNIQUE INDEX `Result_classId_key` ON `Result`(`classId`);

-- CreateIndex
CREATE UNIQUE INDEX `Result_lessonId_key` ON `Result`(`lessonId`);

-- CreateIndex
CREATE UNIQUE INDEX `Result_examId_key` ON `Result`(`examId`);

-- CreateIndex
CREATE UNIQUE INDEX `Result_studentId_key` ON `Result`(`studentId`);

-- CreateIndex
CREATE UNIQUE INDEX `Student_userId_key` ON `Student`(`userId`);

-- CreateIndex
CREATE UNIQUE INDEX `Teacher_userId_key` ON `Teacher`(`userId`);
