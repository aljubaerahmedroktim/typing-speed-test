-- AlterTable
ALTER TABLE `exam` MODIFY `start_time` VARCHAR(191) NOT NULL,
    MODIFY `end_time` VARCHAR(191) NOT NULL;
