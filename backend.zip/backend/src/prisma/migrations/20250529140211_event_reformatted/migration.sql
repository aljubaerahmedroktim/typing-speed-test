/*
  Warnings:

  - A unique constraint covering the columns `[event_name]` on the table `Event` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `event` MODIFY `start_time` VARCHAR(191) NOT NULL,
    MODIFY `end_time` VARCHAR(191) NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX `Event_event_name_key` ON `Event`(`event_name`);
