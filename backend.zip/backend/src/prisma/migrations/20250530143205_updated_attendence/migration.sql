/*
  Warnings:

  - A unique constraint covering the columns `[date]` on the table `StudentAttendence` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[date]` on the table `TeacherAttendence` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX `StudentAttendence_date_key` ON `StudentAttendence`(`date`);

-- CreateIndex
CREATE UNIQUE INDEX `TeacherAttendence_date_key` ON `TeacherAttendence`(`date`);
