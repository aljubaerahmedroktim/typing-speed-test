-- AlterTable
ALTER TABLE `studentattendence` MODIFY `status` ENUM('present', 'absent', 'holiday') NOT NULL;

-- AlterTable
ALTER TABLE `teacherattendence` MODIFY `status` ENUM('present', 'absent', 'holiday') NOT NULL;
