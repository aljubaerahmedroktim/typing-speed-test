import prisma from "../config/db.config.js";

export const authSingleUser = async (req, res, next) => {
	try {
		const { id, role } = req.user;
		const requestedId = Number(req.params.id);

		const requestedUser = await prisma.user.findUnique({
			where: { id: requestedId },
		});

		if (!requestedUser) {
			return res.status(404).json({ msg: "User not found." });
		}

		const admin = await prisma.admin.findUnique({
			where: { userId: Number(id) },
		});

		const requestedAdmin = await prisma.admin.findUnique({
			where: { userId: requestedUser.id },
		});

		console.log("Above admin")

		if (req.user.access_level) {
			if (role === "admin" && req.user.access_level === "super") {
				return next();
			}

			if (
				role === "admin" &&
				req.user.access_level === "regular" &&
				requestedAdmin.access_level !== "super" 
			) {
				return next();
			}
		}

		console.log("Under admin")

		if (role === "teacher" && requestedUser.role === "teacher") {
			return next();
		}

		if (role === "student" && requestedUser.role === "student") {
			return next();
		}

		if (role === "parent" && requestedUser.role === "parent") {
			return next();
		}

		return res
			.status(403)
			.json({ msg: "You don't have permission to access this user." });
	} catch (error) {
		return res.status(500).json({ msg:"From authSingle file", err: error.message });
	}
};
