import jwt from "jsonwebtoken";

export const verifyToken = (req, res, next) => {
	let token;
	let header = req.headers.authorization || req.headers.Authorization;

	if (header && header.startsWith("Bearer")) {
		token = header.split(" ")[1];

		if (!token) {
			return res.status(405).json({ msg: "Token not found." });
		}

		try {
			const decoded = jwt.verify(token, process.env.JWT_SECRET);
			if (!decoded) {
				return res.json({ msg: "Can't verify token" });
			}
			req.user = decoded;
			next();
		} catch (error) {
			return res.status(505).json({ msg: "Server Error", err: error.message });
		}
	} else {
		return res.status(405).json({ msg: "Token not found." });
	}
};
