import prisma from "../config/db.config.js";

export const authRole = (...props) => {
	return async (req, res, next) => {
		const {role, access_level} = req.user;
		if (!props.includes(role) || access_level === "regular") {
			return res.status(404).json({ msg: "Access Denied" });
		}
        next();
	};
};
