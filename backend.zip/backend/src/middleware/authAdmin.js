import prisma from "../config/db.config.js";
import { verifyToken } from "./authMiddleware.js";

export const verifyAdmin = async (req, res, next) => {
	try {
		const hasAdminRole = req.body.role == "admin";

		const existAdmin = await prisma.admin.findMany({
			where: { access_level: "super" },
		});

		if (!hasAdminRole) {
			return next();
		}

		if (existAdmin.length == 0 && hasAdminRole) {
			return next();
		}

		verifyToken(req, res, () => {
			if (req.user.role === "admin" && req.user.access_level === "super") {
				return next();
			}
			return res.status(403).json({
				msg: "Only Super admins can create admins.",
			});
		});
	} catch (error) {
		return res.status(404).json({ err: error.message });
	}
};
