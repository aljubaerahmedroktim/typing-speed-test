import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import routes from "./routes/index.js";

// express config
dotenv.config();
const app = express();
const port = process.env.PORT || 4000;

// middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// routes
app.get("/", (req, res) => {
	res.send("From server.js");
});

app.use(routes);

// listen in port
app.listen(port, () => {
	console.log(`Server started on http://localhost:${port}`);
});
