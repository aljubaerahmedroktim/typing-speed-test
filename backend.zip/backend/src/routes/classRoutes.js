import {Router} from "express"
import { createClass, deleteClass, getClassById, getClasses, updateClass } from "../controllers/classController.js";

const router = Router();

router.get("/", getClasses);
router.get("/:id", getClassById);
router.post("/", createClass);
router.delete("/:id", deleteClass);
router.put("/:id", updateClass);

export default router;