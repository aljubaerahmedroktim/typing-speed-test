import { Router } from "express";
import { createTeacherAttendence, deleteTeacherAttendence, getTeacherAttendence, getTeacherAttendenceById, updateTeacherAttendence } from "../controllers/teacherAttendenceController.js";


const router = Router();

router.get("/", getTeacherAttendence);
router.get("/:id", getTeacherAttendenceById);
router.post("/", createTeacherAttendence);
router.delete("/:id", deleteTeacherAttendence);
router.put("/:id", updateTeacherAttendence);

export default router;
