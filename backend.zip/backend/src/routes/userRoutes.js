import { Router } from "express";
import {
	createUser,
	deleteUserWithRole,
	getAdmin,
	getParent,
	getStudent,
	getTeacher,
	getUserById,
	getUsers,
	updateUserWithRole,
} from "../controllers/userController.js";
import { verifyToken } from "../middleware/authMiddleware.js";
import { authRole } from "../middleware/authRole.js";
import { verifyAdmin } from "../middleware/authAdmin.js";
import { authDeleteRole } from "../middleware/authDeleteRole.js";
import { authSingleUser } from "../middleware/authSingleUser.js";


const router = Router();

router.post("/", verifyAdmin, createUser);

router.get("/", verifyToken, authRole("admin"), getUsers);

router.get("/role/admin", verifyToken, authRole("admin"), getAdmin);
router.get("/role/teacher", verifyToken, authRole("admin"), getTeacher);
router.get("/role/student", verifyToken, authRole("admin"), getStudent);
router.get("/role/parent", verifyToken, authRole("admin"), getParent);

router.get("/:id", verifyToken, authSingleUser, getUserById);
router.delete("/:id", verifyToken, authDeleteRole, deleteUserWithRole);
router.put("/:id", verifyToken, authRole("admin"), updateUserWithRole);


export default router;
