import { Router } from "express";
import {
    createResult,
    deleteResult,
    getResult,
    getResultById,
    updateResult,
} from "../controllers/resultController.js";

const router = Router();

router.get("/", getResult);
router.get("/:id", getResultById);
router.post("/", createResult);
router.delete("/:id", deleteResult);
router.put("/:id", updateResult);

export default router;
