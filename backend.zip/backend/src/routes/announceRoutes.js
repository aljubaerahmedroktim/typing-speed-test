import { Router } from "express";
import { createAnnounce, deleteAnnounce, getAnnounce, getAnnounceById, updateAnnouncement } from "../controllers/announceController.js";
const router = Router();

router.get("/", getAnnounce);
router.get("/:id", getAnnounceById);
router.post("/", createAnnounce);
router.delete("/:id", deleteAnnounce);
router.put("/:id", updateAnnouncement);

export default router;