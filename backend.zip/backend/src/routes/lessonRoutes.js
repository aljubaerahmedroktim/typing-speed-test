import { Router } from "express";
import { createLesson, deleteLesson, getLesson, getLessonById, updateLesson } from "../controllers/lessonController.js";
const router = Router();

router.get("/", getLesson);
router.get("/:id", getLessonById);
router.post("/", createLesson);
router.delete("/:id", deleteLesson);
router.put("/:id", updateLesson);

export default router;
