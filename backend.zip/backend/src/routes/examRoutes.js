import { Router } from "express";
import {
	createExam,
	deleteExam,
	getExam,
	getExamById,
	updateExam,
} from "../controllers/examController.js";

const router = Router();

router.get("/", getExam);
router.get("/:id", getExamById);
router.post("/", createExam);
router.delete("/:id", deleteExam);
router.put("/:id", updateExam);

export default router;
