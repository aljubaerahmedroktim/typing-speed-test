import { Router } from "express";
import announceRoutes from "./announceRoutes.js";
import classRoutes from "./classRoutes.js";
import userRoutes from "./userRoutes.js";
import eventRoutes from "./eventRoutes.js";
import lessonRoutes from "./lessonRoutes.js";
import examRoutes from "./examRoutes.js";
import resultRoutes from "./resultRoutes.js";
import relationRoutes from "./relationRoutes.js";
import studentAttendenceRoutes from "./studentAttendenceRoutes.js";
import teacherAttendenceRoutes from "./teacherAttendenceRoutes.js";
import authRoutes from "./authRoutes.js";

const router = Router();

router.use("/api/user", userRoutes);
router.use("/api/class", classRoutes);
router.use("/api/announcement", announceRoutes);
router.use("/api/event", eventRoutes);
router.use("/api/lesson", lessonRoutes);
router.use("/api/exam", examRoutes);
router.use("/api/result", resultRoutes);
router.use("/api/relation", relationRoutes);
router.use("/api/attendence/student", studentAttendenceRoutes);
router.use("/api/attendence/teacher", teacherAttendenceRoutes);
router.use("/api/login", authRoutes);

export default router;
