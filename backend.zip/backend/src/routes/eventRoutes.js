import { Router } from "express";
import { createEvent, deleteEvent, getEvent, getEventById, updateEvent } from "../controllers/eventController.js";

const router = Router();

router.get("/", getEvent);
router.get("/:id", getEventById);
router.post("/", createEvent);
router.delete("/:id", deleteEvent);
router.put("/:id", updateEvent);

export default router;