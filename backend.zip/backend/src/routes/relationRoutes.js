import { Router } from "express";
import { createRelation, deleteRelation, getRelation, getRelationById, updateRelation } from "../controllers/relationController.js";

const router = Router();

router.get("/", getRelation);
router.get("/:id", getRelationById);
router.post("/", createRelation);
router.delete("/:id", deleteRelation);
router.put("/:id", updateRelation);

export default router;