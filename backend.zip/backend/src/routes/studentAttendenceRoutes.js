import { Router } from "express";
import { createStudentAttendence, deleteStudentAttendence, getStudentAttendence, getStudentAttendenceById, updateStudentAttendence } from "../controllers/studentAttendenceController.js";


const router = Router();

router.get("/", getStudentAttendence);
router.get("/:id", getStudentAttendenceById);
router.post("/", createStudentAttendence);
router.delete("/:id", deleteStudentAttendence);
router.put("/:id", updateStudentAttendence);

export default router;
