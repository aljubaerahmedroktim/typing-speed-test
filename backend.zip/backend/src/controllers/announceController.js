import prisma from "../config/db.config.js";

export const createAnnounce = async (req, res) => {
	try {
		const { title, date, userId } = req.body;
		const checkInvalidData = [title, date, userId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const hasTitle = await prisma.announcement.findUnique({
			where: { title },
		});
		if (hasTitle) {
			return res.json({ msg: "Announcement already exists." });
		}
		const uId = Number(userId);
		await prisma.announcement.create({
			data: {
				title,
				date: new Date(date),
				userId: uId,
			},
		});

		return res.status(201).json({ msg: "Announcement created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getAnnounce = async (req, res) => {
	try {
		const announce = await prisma.announcement.findMany({});
		if (!announce) {
			res.status(401).json({ msg: "No announcement found" });
		}
		return res.status(201).json({ data: announce });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getAnnounceById = async (req, res) => {
	const announceId = Number(req.params.id);
	try {
		const announceData = await prisma.announcement.findUnique({
			where: {
				id: announceId,
			},
		});
		if (!announceData) {
			return res
				.status(404)
				.json({ status: 404, msg: "Announcement not found" });
		}
		res.status(201).json({ data: announceData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteAnnounce = async (req, res) => {
	const announceId = Number(req.params.id);

	try {
		const announceData = await prisma.announcement.findUnique({
			where: { id: announceId },
		});

		if (!announceData) {
			return res
				.status(404)
				.json({ status: 404, msg: "Announcement not found" });
		}

		await prisma.announcement.delete({
			where: { id: announceId },
		});

		return res.status(200).json({
			status: 200,
			msg: "Announcement deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateAnnouncement = async (req, res) => {
	const announceId = Number(req.params.id);
	const { title, date, userId } = req.body;
	const aId = Number(userId);
	const updateData = { title, date };

	try {
		const announce = await prisma.announcement.findUnique({
			where: { id: announceId },
		});

		if (!announce) {
			return res.status(404).json({ msg: "Announcement not found." });
		}

		if (!isNaN(aId) && aId > 0) {
			updateData.userId = aId;
		}

		await prisma.announcement.update({
			where: { id: announceId },
			data: updateData,
		});

		res.status(200).json({ msg: "Announcement updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
