import prisma from "../config/db.config.js";

export const createClass = async (req, res) => {
	try {
		const { class_name, capacity, teacherId } = req.body;
		const checkInvalidData = [class_name, capacity, teacherId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const hasClass = await prisma.class.findUnique({
			where: {
				class_name,
			},
		});
		if (hasClass) {
			return res.json({ msg: "Username already exists." });
		}
		const tId = Number(teacherId);
		await prisma.class.create({
			data: {
				class_name,
				capacity,
				teacherId: tId,
			},
		});

		return res.status(201).json({ msg: "Class created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getClasses = async (req, res) => {
	try {
		const classes = await prisma.class.findMany({});
		if (!classes) {
			res.status(401).json({ msg: "No data found" });
		}
		return res.status(201).json({ data: classes });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getClassById = async (req, res) => {
	const classId = Number(req.params.id);
	try {
		const classData = await prisma.class.findUnique({
			where: {
				id: classId,
			},
			include: {
				event: true,
				lesson: true,
				exam: true,
				result: true,
			},
		});
		if (!classData) {
			return res.status(404).json({ status: 404, msg: "Class not found" });
		}
		res.status(201).json({ data: classData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteClass = async (req, res) => {
	const classId = Number(req.params.id);

	try {
		const classData = await prisma.class.findUnique({
			where: { id: classId },
			include: {
				event: true,
				lesson: true,
				exam: true,
				result: true,
			},
		});

		if (!classData) {
			return res.status(404).json({ status: 404, msg: "Class not found" });
		}

		await prisma.$transaction(async (tx) => {
			if (classData.event.length > 0) {
				await tx.event.deleteMany({ where: { classId } });
			}
			if (classData.lesson.length > 0) {
				await tx.lesson.deleteMany({ where: { classId } });
			}
			if (classData.exam.length > 0) {
				await tx.exam.deleteMany({ where: { classId } });
			}
			if (classData.result.length > 0) {
				await tx.result.deleteMany({ where: { classId } });
			}

			await tx.class.delete({ where: { id: classId } });
		});

		return res.status(200).json({
			status: 200,
			msg: "Class and related fields deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateClass = async (req, res) => {
	const classId = Number(req.params.id);
	const { class_name, capacity, teacherId } = req.body;

	try {
		const classes = await prisma.class.findUnique({ where: { id: classId } });

		if (!classes) {
			return res.status(404).json({ msg: "Class not found." });
		}

		const tId = Number(teacherId);
		const updateData = { class_name, capacity };

		if (!isNaN(tId) && tId > 0) {
			updateData.teacherId = tId;
		}

		await prisma.class.update({
			where: { id: classId },
			data: updateData,
		});

		res.status(200).json({ msg: "Class updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
