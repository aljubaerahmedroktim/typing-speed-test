import prisma from "../config/db.config.js";

export const createEvent = async (req, res) => {
	try {
		const { event_name, date, start_time, end_time, classId } = req.body;
		const checkInvalidData = [
			event_name,
			date,
			start_time,
			end_time,
			classId,
		].some((data) => data === undefined);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const hasEvent = await prisma.event.findUnique({
			where: { event_name },
		});
		if (hasEvent) {
			return res.json({ msg: "Event already exists." });
		}
		const cId = Number(classId);
		await prisma.event.create({
			data: {
				event_name,
				date: new Date(date),
				start_time,
				end_time,
				classId: cId,
			},
		});

		return res.status(201).json({ msg: "Event created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getEvent = async (req, res) => {
	try {
		const event = await prisma.event.findMany({});
		if (!event) {
			res.status(401).json({ msg: "No event found" });
		}
		return res.status(201).json({ data: event });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getEventById = async (req, res) => {
	const eventId = Number(req.params.id);
	try {
		const eventData = await prisma.event.findUnique({
			where: {
				id: eventId,
			},
		});
		if (!eventId) {
			return res.status(404).json({ status: 404, msg: "Event not found" });
		}
		res.status(201).json({ data: eventData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteEvent = async (req, res) => {
	const eventId = Number(req.params.id);

	try {
		const eventData = await prisma.event.findUnique({
			where: { id: eventId },
		});

		if (!eventData) {
			return res.status(404).json({ status: 404, msg: "Event not found" });
		}

		await prisma.event.delete({
			where: { id: eventId },
		});

		return res.status(200).json({
			status: 200,
			msg: "Event deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateEvent = async (req, res) => {
	const eventId = Number(req.params.id);
	const { event_name, date, start_time, end_time, classId } = req.body;
	const cId = Number(classId);
	const updateData = { event_name, date, start_time, end_time };

	try {
		const event = await prisma.event.findUnique({
			where: { id: eventId },
		});

		if (!event) {
			return res.status(404).json({ msg: "Event not found." });
		}

		if (!isNaN(cId) && cId > 0) {
			updateData.classId = cId;
		}

		await prisma.event.update({
			where: { id: eventId },
			data: updateData,
		});

		res.status(200).json({ msg: "Event updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
