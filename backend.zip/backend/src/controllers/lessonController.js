import prisma from "../config/db.config.js";

export const createLesson = async (req, res) => {
	try {
		const { subject_name, teacherId, classId } = req.body;
		const checkInvalidData = [subject_name, teacherId, classId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const hasLesson = await prisma.lesson.findUnique({
			where: {
				subject_name,
			},
		});
		if (hasLesson) {
			return res.json({ msg: "Lesson already exists." });
		}
		const cId = Number(classId);
		const tId = Number(teacherId);

		await prisma.lesson.create({
			data: {
				subject_name,
				teacherId: tId,
				classId: cId,
			},
		});

		return res.status(201).json({ msg: "Class created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getLesson = async (req, res) => {
	try {
		const lesson = await prisma.lesson.findMany({});
		if (!lesson) {
			res.status(401).json({ msg: "No lesson found" });
		}
		return res.status(201).json({ data: lesson });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getLessonById = async (req, res) => {
	const lessonId = Number(req.params.id);
	try {
		const lessonData = await prisma.lesson.findUnique({
			where: {
				id: lessonId,
			},
		});
		if (!lessonData) {
			return res.status(404).json({ status: 404, msg: "Lesson not found" });
		}
		res.status(201).json({ data: lessonData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteLesson = async (req, res) => {
	const lessonId = Number(req.params.id);

	try {
		const lessonData = await prisma.lesson.findUnique({
			where: { id: lessonId },
			include: {
				exam: true,
				result: true,
			},
		});

		if (!lessonData) {
			return res.status(404).json({ status: 404, msg: "Lesson not found" });
		}

		await prisma.$transaction(async (tx) => {
			if (lessonData.exam.length > 0) {
				await tx.exam.deleteMany({ where: { lessonId } });
			}
			if (lessonData.result.length > 0) {
				await tx.result.deleteMany({ where: { lessonId } });
			}

			await tx.lesson.delete({ where: { id: lessonId } });
		});

		return res.status(200).json({ msg: "Lesson deleted successfully" });
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateLesson = async (req, res) => {
	const lessonId = Number(req.params.id);
	const { subject_name, teacherId, classId } = req.body;
	const cId = Number(classId);
	const tId = Number(teacherId);
	const updateData = { subject_name };

	try {
		const lesson = await prisma.lesson.findUnique({
			where: { id: lessonId },
		});

		if (!lesson) {
			return res.status(404).json({ msg: "Lesson not found." });
		}

		if (!isNaN(cId) && cId > 0) {
			updateData.classId = cId;
		}
		if (!isNaN(tId) && tId > 0) {
			updateData.teacherId = tId;
		}

		await prisma.lesson.update({
			where: { id: lessonId },
			data: updateData,
		});

		res.status(200).json({ msg: "Lesson updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
