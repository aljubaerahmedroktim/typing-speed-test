import prisma from "../config/db.config.js";

export const createExam = async (req, res) => {
	try {
		const {
			exam_name,
			full_marks,
			date,
			start_time,
			end_time,
			classId,
			lessonId,
		} = req.body;
		const checkInvalidData = [
			exam_name,
			full_marks,
			date,
			start_time,
			end_time,
			classId,
			lessonId,
		].some((data) => data === undefined);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}

		const cId = Number(classId);
		const lId = Number(lessonId);

		await prisma.exam.create({
			data: {
				exam_name,
				full_marks,
				date: new Date(date),
				start_time,
				end_time,
				classId: cId,
				lessonId: lId,
			},
		});

		return res.status(201).json({ msg: "Exam created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getExam = async (req, res) => {
	try {
		const exam = await prisma.exam.findMany({});
		if (!exam) {
			res.status(401).json({ msg: "No exam found" });
		}
		return res.status(201).json({ data: exam });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getExamById = async (req, res) => {
	const examId = Number(req.params.id);
	try {
		const examData = await prisma.exam.findUnique({
			where: {
				id: examId,
			},
		});
		if (!examData) {
			return res.status(404).json({ status: 404, msg: "Exam not found" });
		}
		res.status(201).json({ data: examData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteExam = async (req, res) => {
	const examId = Number(req.params.id);

	try {
		const examData = await prisma.exam.findUnique({
			where: { id: examId },
			include: {
				result: true,
			},
		});

		if (!examData) {
			return res.status(404).json({ status: 404, msg: "exam not found" });
		}

		await prisma.$transaction(async (tx) => {
			if (examData.result.length > 0) {
				await tx.result.deleteMany({ where: { examId } });
			}

			await tx.exam.delete({ where: { id: examId } });
		});

		return res.status(200).json({ msg: "exam deleted successfully" });
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateExam = async (req, res) => {
	const examId = Number(req.params.id);
	const {
		exam_name,
		full_marks,
		date,
		start_time,
		end_time,
		classId,
		lessonId,
	} = req.body;

	const cId = Number(classId);
	const lId = Number(lessonId);

	const updateData = { exam_name, full_marks, date, start_time, end_time };

	try {
		const exam = await prisma.exam.findUnique({
			where: { id: examId },
		});

		if (!exam) {
			return res.status(404).json({ msg: "exam not found." });
		}

		if (!isNaN(cId) && cId > 0) {
			updateData.classId = cId;
		}
		if (!isNaN(lId) && lId > 0) {
			updateData.lessonId = lId;
		}

		await prisma.exam.update({
			where: { id: examId },
			data: updateData,
		});

		res.status(200).json({ msg: "exam updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
