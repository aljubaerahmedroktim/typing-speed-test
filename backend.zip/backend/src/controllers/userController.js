import bcrypt from "bcrypt";
import prisma from "../config/db.config.js";
export const createUser = async (req, res) => {
	try {
		const {
			full_name,
			username,
			role,
			email,
			password,
			phone,
			blood,
			date_of_birth,
			gender,
			address,
			profile_image,
			access_level,
			teacher_id,
			subject,
			classes,
			student_id,
			class_name,
		} = req.body;

		const hasValidUserData = [
			full_name,
			username,
			role,
			email,
			password,
			phone,
			blood,
			date_of_birth,
			gender,
			address,
			profile_image,
			access_level,
			teacher_id,
			subject,
			classes,
			student_id,
			class_name,
		].some((data) => data === undefined);

		if (hasValidUserData) {
			return res.status(404).json({ msg: "Invalid input." });
		}

		const findUniqueUsername = await prisma.user.findUnique({
			where: {
				username: username,
			},
		});

		const findUniqueEmail = await prisma.user.findUnique({
			where: {
				email: email,
			},
		});

		if (findUniqueUsername) {
			return res.json({ msg: "Username already exists." });
		} else if (findUniqueEmail) {
			return res.json({ msg: "Email already exists." });
		}

		const hashedPassword = await bcrypt.hash(password, 10);

		const newUser = await prisma.user.create({
			data: {
				full_name,
				username,
				role,
				email,
				password: hashedPassword,
				phone,
				blood,
				date_of_birth: new Date(date_of_birth),
				gender,
				address,
				profile_image,
			},
		});

		switch (role) {
			case "admin":
				await prisma.admin.create({
					data: {
						access_level,
						userId: newUser.id,
					},
				});
				break;
			case "teacher":
				await prisma.teacher.create({
					data: {
						teacher_id,
						subject,
						classes,
						userId: newUser.id,
					},
				});
				break;
			case "parent":
				await prisma.parent.create({
					data: {
						userId: newUser.id,
					},
				});
				break;
			case "student":
				await prisma.student.create({
					data: {
						student_id,
						class: class_name,
						userId: newUser.id,
					},
				});
				break;

			default:
				break;
		}

		return res
			.status(201)
			.json({ msg: "User created successfully", data: newUser });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getUsers = async (req, res) => {
	try {
		const allUsers = await prisma.user.findMany({
			include: {
				admin: true,
				teacher: true,
				student: true,
				parent: true,
				announcement: true,
			},
		});
		if (!allUsers) {
			res.status(401).json({ msg: "User not found." });
		}
		return res.status(201).json({ data: allUsers });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getUserById = async (req, res) => {
	const userId = Number(req.params.id);
	const user = await prisma.user.findUnique({
		where: {
			id: userId,
		},
		include: {
			admin: true,
			teacher: true,
			student: true,
			parent: true,
		},
	});

	if (!user) {
		return res.status(404).json({ status: 404, msg: "User not found" });
	}

	res.status(201).json({ data: user });
};

export const deleteUserWithRole = async (req, res) => {
	const userId = Number(req.params.id);

	try {
		const user = await prisma.user.findUnique({
			where: { id: userId },
			include: {
				admin: true,
				teacher: true,
				student: true,
				parent: true,
			},
		});

		if (!user) {
			return res.status(404).json({ status: 404, msg: "User not found" });
		}

		const hasSuperAdmin = await prisma.admin.findMany({
			where: { access_level: "super" },
		});

		if (hasSuperAdmin.length === 1) {
			return res.status(200).json({
				msg: "Only 1 Super Admin exist. Create another before deleting",
			});
		}

		await prisma.$transaction(async (tx) => {
			if (user.admin.length > 0) {
				await tx.admin.deleteMany({ where: { userId } });
			}
			if (user.teacher.length > 0) {
				await tx.teacher.deleteMany({ where: { userId } });
			}
			if (user.student.length > 0) {
				await tx.student.deleteMany({ where: { userId } });
			}
			if (user.parent.length > 0) {
				await tx.parent.deleteMany({ where: { userId } });
			}

			await tx.user.delete({ where: { id: userId } });
		});

		return res.status(200).json({
			status: 200,
			msg: "User and related roles deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateUserWithRole = async (req, res) => {
	const userId = Number(req.params.id);
	const {
		full_name,
		password,
		phone,
		address,
		profile_image,
		access_level,
		subject,
		classes,
		class_name,
		status,
	} = req.body;

	try {
		const user = await prisma.user.findUnique({ where: { id: userId } });

		if (!user) {
			return res.status(404).json({ msg: "User not found." });
		}

		const userUpdate = await prisma.user.update({
			where: { id: userId },
			data: { full_name, password, phone, address, profile_image, status },
		});

		switch (user.role) {
			case "admin":
				await prisma.admin.updateMany({
					where: { userId },
					data: { access_level },
				});
				break;

			case "teacher":
				await prisma.teacher.updateMany({
					where: { userId },
					data: { subject, classes },
				});
				break;

			case "student":
				await prisma.student.updateMany({
					where: { userId },
					data: { class: class_name },
				});
				break;
		}

		res.status(200).json({ msg: "User updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getAdmin = async (req, res) => {
	const allAdmins = await prisma.admin.findMany({});
	if (allAdmins) {
		return res.status(200).json({ data: allAdmins });
	}
	return res.status(404).json({ msg: "Data not found." });
};

export const getTeacher = async (req, res) => {
	const allTeacher = await prisma.teacher.findMany({});
	if (allTeacher) {
		return res.status(200).json({ data: allTeacher });
	}
	return res.status(404).json({ msg: "Data not found." });
};

export const getStudent = async (req, res) => {
	const allStudent = await prisma.student.findMany({});
	if (allStudent) {
		return res.status(200).json({ data: allStudent });
	}
	return res.status(404).json({ msg: "Data not found." });
};

export const getParent = async (req, res) => {
	const allParent = await prisma.parent.findMany({});
	if (allParent) {
		return res.status(200).json({ data: allParent });
	}
	return res.status(404).json({ msg: "Data not found." });
};
