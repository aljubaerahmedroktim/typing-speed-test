import prisma from "../config/db.config.js";

export const createResult = async (req, res) => {
	try {
		const {
			exam_name,
			score,
			teacherId,
			classId,
			lessonId,
			examId,
			studentId,
		} = req.body;
		const checkInvalidData = [
			exam_name,
			score,
			teacherId,
			classId,
			lessonId,
			examId,
			studentId,
		].some((data) => data === undefined);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}

		const classID = Number(classId);
		const lessonID = Number(lessonId);
		const teacherID = Number(teacherId);
		const examID = Number(examId);
		const studentID = Number(studentId);

		await prisma.result.create({
			data: {
				exam_name,
				score,
				teacherId: teacherID,
				classId: classID,
				lessonId: lessonID,
				examId: examID,
				studentId: studentID,
			},
		});

		return res.status(201).json({ msg: "Result created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getResult = async (req, res) => {
	try {
		const result = await prisma.result.findMany({});
		if (!result) {
			res.status(401).json({ msg: "No result found" });
		}
		return res.status(201).json({ data: result });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getResultById = async (req, res) => {
	const resultId = Number(req.params.id);
	try {
		const resultData = await prisma.result.findUnique({
			where: {
				id: resultId,
			},
		});
		if (!resultData) {
			return res.status(404).json({ status: 404, msg: "Result not found" });
		}
		res.status(201).json({ data: resultData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteResult = async (req, res) => {
	const resultId = Number(req.params.id);

	try {
		const resultData = await prisma.result.findUnique({
			where: { id: resultId },
		});

		if (!resultData) {
			return res.status(404).json({ status: 404, msg: "Result not found" });
		}

		await prisma.result.delete({
			where: { id: resultId },
		});

		return res.status(200).json({ msg: "Result deleted successfully" });
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateResult = async (req, res) => {
	const resultId = Number(req.params.id);
	const { exam_name, score, teacherId, classId, lessonId, examId, studentId } =
		req.body;

	const classID = Number(classId);
	const lessonID = Number(lessonId);
	const teacherID = Number(teacherId);
	const examID = Number(examId);
	const studentID = Number(studentId);

	const updateData = { exam_name, score };

	try {
		const result = await prisma.result.findUnique({
			where: { id: resultId },
		});

		if (!result) {
			return res.status(404).json({ msg: "Result not found." });
		}

		if (!isNaN(classID) && classID > 0) {
			updateData.classId = classID;
		}
		if (!isNaN(lessonID) && lessonID > 0) {
			updateData.lessonId = lessonID;
		}
		if (!isNaN(teacherID) && teacherID > 0) {
			updateData.teacherId = teacherID;
		}
		if (!isNaN(examID) && examID > 0) {
			updateData.examId = examID;
		}
		if (!isNaN(studentID) && studentID > 0) {
			updateData.studentId = studentID;
		}

		await prisma.result.update({
			where: { id: resultId },
			data: updateData,
		});

		res.status(200).json({ msg: "Result updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
