import prisma from "../config/db.config.js";

const dateTime = new Date();
const onlyDate = new Date(
	dateTime.getFullYear(),
	dateTime.getMonth(),
	dateTime.getDay()
);

export const createTeacherAttendence = async (req, res) => {
	try {
		const { status, teacherId } = req.body;
		const checkInvalidData = [status, teacherId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const teacherID = Number(teacherId);

		const presentToday = await prisma.teacherAttendence.findUnique({
			where: { teacherId: teacherID, date: onlyDate },
		});
		if (presentToday) {
			return res.json({ msg: "Today's attendence taken already!" });
		}
		await prisma.teacherAttendence.create({
			data: {
				status,
				date: onlyDate,
				teacherId: teacherID,
			},
		});

		return res.status(201).json({ msg: "Attendence given." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getTeacherAttendence = async (req, res) => {
	try {
		const attendence = await prisma.teacherAttendence.findMany({});
		if (!attendence) {
			res.status(401).json({ msg: "No attendence found" });
		}
		return res.status(201).json({ data: attendence });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getTeacherAttendenceById = async (req, res) => {
	const attendenceId = Number(req.params.id);
	try {
		const attendenceData = await prisma.teacherAttendence.findUnique({
			where: {
				id: attendenceId,
			},
		});
		if (!attendenceData) {
			return res.status(404).json({ status: 404, msg: "Attendence not found" });
		}
		res.status(201).json({ data: attendenceData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteTeacherAttendence = async (req, res) => {
	const attendenceId = Number(req.params.id);

	try {
		const attendenceData = await prisma.teacherAttendence.findUnique({
			where: { id: attendenceId },
		});

		if (!attendenceData) {
			return res.status(404).json({ status: 404, msg: "Attendence not found" });
		}

		await prisma.teacherAttendence.delete({
			where: { id: attendenceId },
		});

		return res.status(200).json({
			status: 200,
			msg: "Attendence deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateTeacherAttendence = async (req, res) => {
	const attendenceId = Number(req.params.id);
	const { status, teacherId } = req.body;
	const teacherID = Number(teacherId);
	const updateData = { status };

	try {
		const attendence = await prisma.teacherAttendence.findUnique({
			where: { id: attendenceId },
		});

		if (!attendence) {
			return res.status(404).json({ msg: "Attendence not found." });
		}

		if (!isNaN(teacherID) && teacherID > 0) {
			updateData.teacherId = teacherID;
		}

		await prisma.teacherAttendence.update({
			where: { id: attendenceId },
			data: updateData,
		});

		res.status(200).json({ msg: "Attendence updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
