import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import prisma from "../config/db.config.js";

export const Login = async (req, res) => {
	try {
		const { password, email } = req.body;
		const user = await prisma.user.findUnique({
			where: { email },
		});
		const admin = await prisma.admin.findUnique({
			where: { userId: user.id },
		});

		if (!user) {
			return res.status(404).json({ msg: "User not found." });
		}

		const isMatch = await bcrypt.compare(password, user.password);
		if (!isMatch) {
			return res.status(400).json({ msg: "Invalid Password" });
		}

		const data = {
			id: user.id,
			email: user.email,
			username: user.username,
			role: user.role,
			...(user.role === "admin" && admin
				? { access_level: admin.access_level }
				: {}),
		};

		const token = jwt.sign(data, process.env.JWT_SECRET, {
			expiresIn: "1h",
		});

		res.status(200).json({ token });
	} catch (error) {
		return res.status(500).json({ msg: "server error", err: error.message });
	}
};
