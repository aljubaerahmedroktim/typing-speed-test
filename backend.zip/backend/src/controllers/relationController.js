// student-parent realtion
import prisma from "../config/db.config.js";

export const createRelation = async (req, res) => {
	try {
		const { parentId, studentId } = req.body;
		const checkInvalidData = [parentId, studentId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}

		const parentID = Number(parentId);
		const studentID = Number(studentId);

		console.log({ parentID, studentID });

		await prisma.parentStudent.create({
			data: {
				parentId: parentID,
				studentId: studentID,
			},
		});

		console.log("Hello -> ", { parentID, studentID });

		return res
			.status(201)
			.json({ msg: "Parent-student relation created successfully" });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getRelation = async (req, res) => {
	try {
		const psr = await prisma.parentStudent.findMany({});
		if (!psr) {
			res.status(401).json({ msg: "No psr found" });
		}
		return res.status(201).json({ data: psr });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getRelationById = async (req, res) => {
	const psrId = Number(req.params.id);
	try {
		const psrData = await prisma.parentStudent.findUnique({
			where: {
				id: psrId,
			},
		});
		if (!psrData) {
			return res.status(404).json({ status: 404, msg: "PSR not found" });
		}
		res.status(201).json({ data: psrData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteRelation = async (req, res) => {
	const psrId = Number(req.params.id);

	try {
		const psrData = await prisma.parentStudent.findUnique({
			where: { id: psrId },
		});

		if (!psrData) {
			return res.status(404).json({ status: 404, msg: "PSR not found" });
		}

		await prisma.parentStudent.delete({
			where: { id: psrId },
		});

		return res.status(200).json({ msg: "PSR deleted successfully" });
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateRelation = async (req, res) => {
	const psrId = Number(req.params.id);
	const { parentId, studentId } = req.body;

	const parentID = Number(parentId);
	const studentID = Number(studentId);

	const updateData = {};

	try {
		const psr = await prisma.parentStudent.findUnique({
			where: { id: psrId },
		});

		if (!psr) {
			return res.status(404).json({ msg: "PSR not found." });
		}

		if (!isNaN(parentID) && parentID > 0) {
			updateData.parentId = parentID;
		} else if (!isNaN(studentID) && studentID > 0) {
			updateData.studentId = studentID;
		} else {
			return res.status(404).json({ msg: "Nothing to update" });
		}

		await prisma.parentStudent.update({
			where: { id: psrId },
			data: updateData,
		});

		res.status(200).json({ msg: "PSR updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
