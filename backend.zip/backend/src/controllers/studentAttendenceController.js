import prisma from "../config/db.config.js";

const dateTime = new Date();
const onlyDate = new Date(
	dateTime.getFullYear(),
	dateTime.getMonth(),
	dateTime.getDay()
);

export const createStudentAttendence = async (req, res) => {
	try {
		const { status, studentId } = req.body;
		const checkInvalidData = [status, studentId].some(
			(data) => data === undefined
		);
		if (checkInvalidData) {
			return res.status(404).json({ msg: "Invalid input." });
		}
		const studentID = Number(studentId);

		const presentToday = await prisma.studentAttendence.findUnique({
			where: { studentId: studentID, date: onlyDate },
		});
		if (presentToday) {
			return res.json({ msg: "Today's attendence taken already!" });
		}
		await prisma.studentAttendence.create({
			data: {
				status,
				date: onlyDate,
				studentId: studentID,
			},
		});

		return res.status(201).json({ msg: "Attendence given." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getStudentAttendence = async (req, res) => {
	try {
		const attendence = await prisma.studentAttendence.findMany({});
		if (!attendence) {
			res.status(401).json({ msg: "No attendence found" });
		}
		return res.status(201).json({ data: attendence });
	} catch (error) {
		return res.status(500).json({ msg: "Server error", err: error.message });
	}
};

export const getStudentAttendenceById = async (req, res) => {
	const attendenceId = Number(req.params.id);
	try {
		const attendenceData = await prisma.studentAttendence.findUnique({
			where: {
				id: attendenceId,
			},
		});
		if (!attendenceData) {
			return res.status(404).json({ status: 404, msg: "Attendence not found" });
		}
		res.status(201).json({ data: attendenceData });
	} catch (err) {
		return res.status(500).json({ msg: "Server error", err: err.message });
	}
};

export const deleteStudentAttendence = async (req, res) => {
	const attendenceId = Number(req.params.id);

	try {
		const attendenceData = await prisma.studentAttendence.findUnique({
			where: { id: attendenceId },
		});

		if (!attendenceData) {
			return res.status(404).json({ status: 404, msg: "Attendence not found" });
		}

		await prisma.studentAttendence.delete({
			where: { id: attendenceId },
		});

		return res.status(200).json({
			status: 200,
			msg: "Attendence deleted successfully",
		});
	} catch (err) {
		return res
			.status(500)
			.json({ status: 500, msg: "Server error", err: err.message });
	}
};

export const updateStudentAttendence = async (req, res) => {
	const attendenceId = Number(req.params.id);
	const { status, studentId } = req.body;
	const studentID = Number(studentId);
	const updateData = { status };

	try {
		const attendence = await prisma.studentAttendence.findUnique({
			where: { id: attendenceId },
		});

		if (!attendence) {
			return res.status(404).json({ msg: "Attendence not found." });
		}

		if (!isNaN(studentID) && studentID > 0) {
			updateData.studentId = studentID;
		}

		await prisma.studentAttendence.update({
			where: { id: attendenceId },
			data: updateData,
		});

		res.status(200).json({ msg: "Attendence updated successfully." });
	} catch (error) {
		res.status(500).json({ msg: "Server error", err: error.message });
	}
};
